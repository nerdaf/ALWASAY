first import the db.sql file located at database/db.sql
then change the database properties in includes db.php
now, run project

admin username is-- electronixadmin
password is-- 12345678

THANKS.

The World is Fake.